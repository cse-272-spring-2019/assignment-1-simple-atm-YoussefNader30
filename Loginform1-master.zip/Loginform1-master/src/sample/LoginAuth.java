package sample;

public class LoginAuth {

}