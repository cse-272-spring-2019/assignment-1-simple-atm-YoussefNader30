module Loginform1 {
    requires javafx.fxml;
    requires javafx.controls;
    opens sample;
}